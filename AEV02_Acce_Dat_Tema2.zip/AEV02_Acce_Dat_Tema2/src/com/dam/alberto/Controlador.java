package com.dam.alberto;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Controlador {

	static private  Vista vista;
	static private Model modelo;

	
	
	public Controlador(Vista vista, Model modelo) {
		// TODO Auto-generated constructor stub7
		this.vista = vista;
		this.modelo = modelo;
		mostrarContenido();
		iniciarEventos();
	}
	
	public void iniciarEventos(){
		
		vista.getBtnBuscar().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(vista.getTextFieldBuscar().getText().isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(),"Error, no hay ninguna palabra", "Resultado", JOptionPane.ERROR_MESSAGE);
				}else {
					String palabra = vista.getTextFieldBuscar().getText();
					JOptionPane.showMessageDialog(new JFrame(), "La palabra " + palabra + " está " + modelo.buscar(palabra) + " veces", "Resultado", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
		vista.getBtnReemplazar().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String palabra = vista.getTextFieldBuscar().getText();
				String palabraNueva = vista.getTextFieldReemplazar().getText();
				JOptionPane.showMessageDialog(new JFrame(), "ha cambiado " + palabra + " por " + palabraNueva, "Resultado", JOptionPane.INFORMATION_MESSAGE);
				ArrayList<String> lineas = modelo.remplazar(palabra, palabraNueva);
				String contenido = String.join("\n", lineas);  // Unir les línies amb salts de línia
				vista.getTextAreaModificado().setText(contenido);
			
			}
		});
		
	}

	
	
	public void mostrarContenido() {
		
		 ArrayList<String> lineas = modelo.LeerRuta();
		 String contenido = String.join("\n", lineas);  // Unir les línies amb salts de línia
		 vista.getTextAreaOriginal().setText(contenido);
		
	}
	

	
}
