package com.dam.alberto;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Model {
	
	static ArrayList<String> lineas = new ArrayList<String>();
    static String rutaOrigen = "pepe.txt";  
    
    static File f = new File(rutaOrigen);

    public Model() {
    }

    public static ArrayList<String> LeerRuta() {

        try {
            lineas.clear();  
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);

            String linea;

            while ((linea = br.readLine()) != null) {
                lineas.add(linea);
                System.out.println(lineas);
            }

            br.close();
        } catch (IOException e) {
            System.out.println("S'ha produït un error en llegir el fitxer.");
            e.printStackTrace();
        }

        return lineas;
    }
   
	public int  buscar(String palabra){
		
		int resultado =0;
		String []comprueba;
		
		try {
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);

	        String linea;
	       
	        while ((linea = br.readLine()) != null) {
                
	        	comprueba = linea.split(" "); 
	        	
	        	for(int i = 0; i<comprueba.length;i++) {
	        		if(comprueba[i].equals(palabra)) {
	        			resultado++;
	        		}
	        	}
	        	
            }
			
			
		} catch (IOException e) {
            System.out.println("S'ha produït un error en llegir el fitxer.");
            e.printStackTrace();
        }
        
		
		return resultado;
		
	}
	public ArrayList<String> remplazar(String palabra, String PalabraNueva){
		String []comprueba;
		
		try {
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);

	        String linea;
	       
	        while ((linea = br.readLine()) != null) {
                
	        	comprueba = linea.split(" "); 
	        	
	        	for(int i = 0; i<comprueba.length;i++) {
	        		if(comprueba[i].equals(palabra)) {
	        			lineas.add(PalabraNueva);
	        		}else {
	        			lineas.add(comprueba[i]);
	        		}
	        	}
	        	
            }
			
			
		} catch (IOException e) {
            System.out.println("S'ha produït un error en llegir el fitxer.");
            e.printStackTrace();
        }
		
		
		
		return lineas;
		
	}
	
}

