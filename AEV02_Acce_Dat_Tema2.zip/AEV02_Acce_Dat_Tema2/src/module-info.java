/**
 * 
 */
/**
 * 
 */
module AEV02_Acce_Dat_Tema2 {
	requires java.desktop;
}