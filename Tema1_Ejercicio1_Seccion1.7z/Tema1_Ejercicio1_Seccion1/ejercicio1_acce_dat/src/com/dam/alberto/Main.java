package com.dam.alberto;

import java.io.File;
import java.util.Scanner;




public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String nombredirectorio;
		System.out.println("Dime un directorio");
		nombredirectorio = teclado.nextLine();
		
		File file= new File(nombredirectorio);
		
		if(file.isDirectory()) {
			System.out.println(file.getName());
			System.out.println(file.getPath());
			System.out.println(file.getAbsolutePath());
			System.out.println(file.canExecute());
			System.out.println(file.canRead());
			System.out.println(file.isAbsolute());
		}else {
			System.out.println("No existe ese directorio");
		}
		
		
		
	}

}
