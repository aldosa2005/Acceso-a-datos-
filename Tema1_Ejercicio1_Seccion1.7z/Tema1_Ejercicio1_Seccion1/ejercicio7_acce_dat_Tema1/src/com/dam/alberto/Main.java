package com.dam.alberto;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String nombredirectorio;
		
		ArrayList<Filtro> f= new ArrayList<>();
		
		System.out.println("Dime un directorio");
		nombredirectorio = teclado.nextLine();
		
		File file= new File(nombredirectorio);
		
		 System.out.println("Dime las extensiones separadas por comas (por ejemplo, .txt,.java,.jpg)");
	     String extensionesInput = teclado.nextLine();
	     String[] extensionesArray = extensionesInput.split("\\s*,\\s*");
	     
		for(String extension : extensionesArray) {
			Filtro filtro = new Filtro(extension);
			
			f.add(filtro);
		}
		
		
		for(File exten : file.listFiles()) {
			for(Filtro filtros : f) {
				if(filtros.accept(exten)) {
					System.out.println(exten.getName());
				}	
			}
			
				
		}
		
		
		
	}

}
