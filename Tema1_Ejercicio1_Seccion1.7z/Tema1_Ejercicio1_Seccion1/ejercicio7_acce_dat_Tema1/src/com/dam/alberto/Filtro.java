package com.dam.alberto;

import java.io.File;
import java.io.FileFilter;

public class Filtro implements FileFilter{

	protected String extension;
	
	public Filtro(String extension) {
		this.extension=extension;
	}
	
	
	@Override
	public boolean accept(File file) {

		if(file.getName().endsWith(extension)) {
			return true;
		}else {
			return false;
		}
		
	}


}
