package com.dam.alberto;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String nombredirectorio;
		String extension;
		
		System.out.println("Dime un directorio");
		nombredirectorio = teclado.nextLine();
		System.out.println("Dime una extension");
		extension=teclado.nextLine();
		Filtro filtro = new Filtro(extension);
		
		File file= new File(nombredirectorio);
	
		for(File exten : file.listFiles()) {
			if(filtro.accept(exten) || extension.equals(null) || extension.equals(".")) {
				System.out.println(exten.getName());
			}
				
		}
		
		
	}

}
