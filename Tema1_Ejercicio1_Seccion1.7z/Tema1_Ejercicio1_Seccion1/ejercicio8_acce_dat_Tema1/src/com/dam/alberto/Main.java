package com.dam.alberto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);
		
		String nombrearchivo;
		
		FileReader fr = null;
		BufferedReader br = null;
		FileWriter fw = null;
		
		System.out.println("Dime un archivo");
		nombrearchivo = teclado.nextLine();
		
		File file = new File(nombrearchivo);
		
		
		try {
			fr = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 br = new BufferedReader(fr);
		
		while(br!=null) {
			try {
				br.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
