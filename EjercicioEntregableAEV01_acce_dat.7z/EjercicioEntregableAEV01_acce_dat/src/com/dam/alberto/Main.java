package com.dam.alberto;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int menu;
		
		String Nombre;
		String nuevoNombre;
		String nuevoFichero;
		
		System.out.println("Dime un directorio o fichero");
		Nombre = teclado.nextLine();
		
		File file= new File(Nombre);
		
		System.out.println("Dime que quieres hacer:\n1.getInformación \n2.Crear carpeta \n3.Crear fitxer \n4.Eliminar \n5.Renombrar");
		menu = teclado.nextInt();
		
		switch(menu) {
		
		case 1:
			
			getInformacio(file);
			
			break;
		case 2:
			
			teclado.nextLine();
			System.out.println("Para crear la carpeta dime la ruta absoluta de donde quieres que este");
			nuevoNombre = teclado.nextLine();
			
			getCrearCarpeta(nuevoNombre);
			
			break;
		
		case 3:
			teclado.nextLine();
			System.out.println("Dime un nombre para el fichero");
			nuevoFichero = teclado.nextLine();
			
			getCrearFichero(nuevoFichero);
			
			break;	
		case 4:
			
			teclado.nextLine();
			System.out.println("Pasame la ruta absoluta para eliminar un fichero");
			nuevoFichero = teclado.nextLine();
			
			getEliminarFichero(nuevoFichero);
			
			
			break;	
		case 5:
			
			teclado.nextLine();
			System.out.println("Pasame el nuevo nombre");
			nuevoFichero = teclado.nextLine();
			
			getRenombrarFichero(file, nuevoFichero);
			
			break;
		default:
			System.out.println("Error, introduzca un numero valido");
			break;
		}
		
	}
	
	public static void getInformacio(File file) {
		
		
		
		if(file.isDirectory()) {
			System.out.println("Nombre: " + file.getName());
			System.out.println("Es un directorio");
			System.out.println("Ruta absoluta: " +file.getAbsolutePath());
			System.out.println("Última vez modificado: " +file.lastModified());
			System.out.println("Esta oculto: " +file.isHidden());
			System.out.println("Número de elemoentos: " +file.list().length);
			System.out.println("Espacio libre: " +file.getFreeSpace());
			System.out.println("Espacio disponible: " +file.getUsableSpace());
			System.out.println("Espacio total: " +file.getTotalSpace());
		}else if(file.isFile()) {
			System.out.println("Nombre: " +file.getName());
			System.out.println("Es un fichero");
			System.out.println("Ruta abbsoluta: " +file.getAbsolutePath());
			System.out.println("Última vez modificado: " +file.lastModified());
			System.out.println("Esta oculto: " +file.isHidden());
			System.out.println("Grandaria en bytes: " +file.getFreeSpace());
		}else {
			System.out.println("No existe ese directorio");
		}
	}
	
	public static void getCrearCarpeta(String nuevoNombre) {
		
		File nombreNuevoDirectorio= new File(nuevoNombre);
		
		try {
			if(nombreNuevoDirectorio.mkdir()) {
				System.out.println("Carpeta creada");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void getCrearFichero(String nuevoFichero) {
		
		
		File fichero = new File(nuevoFichero);
		try {
			if(fichero.createNewFile()) {
				System.out.println("Fichero creado");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public static void getEliminarFichero(String nuevoFichero) {
		
		File EliminarFichero = new File(nuevoFichero);
		try {
			if(EliminarFichero.delete()) {
				System.out.println("Fichero eliminado");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static void getRenombrarFichero(File file, String nuevoFichero) {
		File renombrarFichero = new File(nuevoFichero);
		try {
			if(file.renameTo(renombrarFichero)) {
				System.out.println("Fichero modificado");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
